class CNConfig:
    interp_factor = 0.075
    sigma = 0.2
    lambda_= 0.01
    output_sigma_factor=1./16
    padding=1
    cn_type = 'pyECO'
