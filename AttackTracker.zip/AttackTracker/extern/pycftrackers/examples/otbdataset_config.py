class OTBDatasetConfig:
    """
    David(300:770), Football1(1:74), Freeman3(1:460), Freeman4(1:283)
    """
    frames={
        "David":[300,770],
        "Football1":[1,74],
        "Freeman4":[1,283],
        'Freeman3':[1,460]
    }
