class GPUConfig:
    use_gpu=True
    gpu_id=2

gpu_config=GPUConfig()