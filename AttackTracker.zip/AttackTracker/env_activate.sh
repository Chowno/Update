#!/bin/bash
export PATH="/home/guoqing/anaconda3/bin:$PATH"
source activate
conda activate siamdw
cd /home/guoqing/projects/BlurAttack/experiments