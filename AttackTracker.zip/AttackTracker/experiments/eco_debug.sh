
# conclution: when eplison=2e-1, MAP tends to be reasonable
# $1 : gpu id
echo "Processing method ECO, Dataset OTB100, with gpu $1"

bash white_model_test.sh eco eco ua $1