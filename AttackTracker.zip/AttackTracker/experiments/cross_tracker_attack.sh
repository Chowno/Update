#!/usr/bin/env bash
bash cross_model_relax.sh r50 eco ua 0