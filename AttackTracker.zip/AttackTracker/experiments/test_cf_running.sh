#!/usr/bin/env bash
bash test_cf.sh mosse
bash test_cf.sh bacf
bash test_cf.sh strcf

