
bash cross_model_test.sh alex mobile ua 1
bash cross_model_test.sh alex r50 ua 1


